package com.example.ejb;

import jakarta.ejb.Stateless;

@Stateless
public class CalculatorBean {
    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public int multiply(int a, int b) {
        return a * b;
    }

    public int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return a / b;
    }

    public int mod(int a, int b) {
        return a % b;
    }

    public double power(int a, int b) {
        return Math.pow(a, b);
    }

    public int square(int a) {
        return a * a;
    }

    public double sqrt(int a) {
        return Math.sqrt(a);
    }
}
