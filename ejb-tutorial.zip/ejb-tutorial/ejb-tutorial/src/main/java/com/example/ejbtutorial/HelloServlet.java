package com.example.ejbtutorial;

import com.example.ejb.CalculatorBean;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/hello")
public class HelloServlet extends HttpServlet {

    @EJB
    private CalculatorBean calculatorBean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Example of adding two numbers
        int addResult = calculatorBean.add(10, 5);
        response.getWriter().println("10 + 5 = " + addResult);

        // Example of subtracting two numbers
        int subtractResult = calculatorBean.subtract(10, 5);
        response.getWriter().println("10 - 5 = " + subtractResult);

        // Example of multiplying two numbers
        int multiplyResult = calculatorBean.multiply(10, 5);
        response.getWriter().println("10 * 5 = " + multiplyResult);

        // Example of dividing two numbers
        try {
            int divideResult = calculatorBean.divide(10, 5);
            response.getWriter().println("10 / 5 = " + divideResult);
        } catch (ArithmeticException e) {
            response.getWriter().println("Error: " + e.getMessage());
        }

        // Example of modulus operation
        int modResult = calculatorBean.mod(10, 5);
        response.getWriter().println("10 % 5 = " + modResult);

        // Example of calculating power
        double powerResult = calculatorBean.power(2, 3);
        response.getWriter().println("2 ^ 3 = " + powerResult);

        // Example of squaring a number
        int squareResult = calculatorBean.square(5);
        response.getWriter().println("5 ^ 2 = " + squareResult);

        // Example of square root of a number
        double sqrtResult = calculatorBean.sqrt(25);
        response.getWriter().println("sqrt(25) = " + sqrtResult);
    }
}
